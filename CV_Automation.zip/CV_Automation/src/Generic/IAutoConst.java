package Generic;

public interface IAutoConst {
	 String CHROME_KEY="webdriver.chrome.driver";
	 String CHROME_VALUE="./driver/chromedriver.exe";
	 String GECKO_KEY="webdriver.gecko.driver";
	 String GECKO_VALUE="./driver/geckodriver.exe";
	 String xlpath="./data/TestData.xlsx";
}
